import React, { useState } from 'react'
import axios from 'axios'

function SosButton({apiBase, user}){
  const [loading, setLoading] = useState(false)
  async function sendSOS(){
    setLoading(true)
    try {
      await axios.post(`${apiBase}/sos`, { user_id: user.phone, phones: [user.phone], message: 'SOS from web demo' })
      alert('SOS sent (demo)')
    } catch(e){ alert('Failed to send SOS') }
    setLoading(false)
  }
  return <button className='button' onClick={sendSOS}>{loading ? 'Sending...' : 'SOS'}</button>
}

export default function Dashboard({ user, logout }){
  const apiBase = import.meta.env.VITE_API_BASE || 'http://localhost:8000'
  return (
    <div className='container'>
      <div className='flex justify-between items-center'>
        <h2 className='text-xl'>Welcome, {user.phone}</h2>
        <button onClick={logout} className='text-sm underline'>Logout</button>
      </div>
      <section className='mt-6'>
        <h3 className='font-semibold'>Safety</h3>
        <div className='mt-4'><SosButton apiBase={apiBase} user={user} /></div>
      </section>
      <section className='mt-6'>
        <h3 className='font-semibold'>Finance (demo)</h3>
        <p className='mt-2'>Earnings tracker and loan application will be available here.</p>
      </section>
    </div>
  )
}
