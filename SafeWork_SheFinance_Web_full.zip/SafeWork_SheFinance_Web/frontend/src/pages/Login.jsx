import React, { useState } from 'react'

export default function Login({ onLogin }){
  const [phone, setPhone] = useState('')
  return (
    <div className='container'>
      <h1 className='text-2xl font-bold'>SafeWork+SheFinance — Web</h1>
      <p className='mt-4'>Enter phone to sign in (Supabase Auth will be used in production)</p>
      <input className='mt-4 p-2 border' placeholder='+2547...' value={phone} onChange={e=>setPhone(e.target.value)} />
      <div className='mt-4'>
        <button className='button' onClick={()=>onLogin({phone})}>Sign In (demo)</button>
      </div>
    </div>
  )
}
