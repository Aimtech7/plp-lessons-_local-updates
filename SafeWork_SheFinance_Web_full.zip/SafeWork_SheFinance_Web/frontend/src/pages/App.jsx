import React, { useState } from 'react'
import Dashboard from './Dashboard'
import Login from './Login'

export default function App(){
  const [user, setUser] = useState(null)
  return user ? <Dashboard user={user} logout={()=>setUser(null)} /> : <Login onLogin={u=>setUser(u)} />
}
