# SafeWork+SheFinance — Web Full-Stack Scaffold

This repository contains a minimal full-stack scaffold for SafeWork+SheFinance:
- Frontend: Vite + React + Tailwind (demo UI)
- Backend: FastAPI (endpoints for SOS, MPESA, webhooks)
- Supabase placeholders for Auth & DB
- Docs and example env files included

## Quickstart (local)
### Backend
```
cd server
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
./run.sh
```
### Frontend
```
cd frontend
npm install
npm run dev
```
Open http://localhost:3000

## Notes
- This scaffold uses placeholders for Twilio/M-Pesa/Supabase; you must add keys in .env files and implement integration code for production.
- See /docs for setup guides.
