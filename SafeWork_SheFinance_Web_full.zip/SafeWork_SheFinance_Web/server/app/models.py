from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class User(BaseModel):
    id: str
    full_name: Optional[str]
    phone: Optional[str]
    email: Optional[str]

class Earning(BaseModel):
    id: Optional[str]
    user_id: str
    amount: float
    date: Optional[datetime]
    notes: Optional[str]
