from fastapi import FastAPI, Request
from pydantic import BaseModel
import os
from dotenv import load_dotenv
import httpx

load_dotenv()
app = FastAPI(title='SafeWork+SheFinance API')

class SosPayload(BaseModel):
    user_id: str
    phones: list
    message: str = 'SOS!'

@app.get('/health')
async def health():
    return {'status':'ok'}

@app.post('/sos')
async def sos(payload: SosPayload):
    print('SOS payload', payload.dict())
    # Here you would call Twilio or Africa's Talking via server-side secrets
    return {'ok':True, 'demo':True}

class MpesaPayload(BaseModel):
    amount: float
    phone: str

@app.post('/mpesa/pay')
async def mpesa_pay(payload: MpesaPayload):
    print('MPESA pay request', payload.dict())
    return {'ok':True, 'demo':True}

@app.post('/webhooks/mpesa')
async def mpesa_webhook(req: Request):
    data = await req.json()
    print('mpesa webhook', data)
    return {'ok':True}
