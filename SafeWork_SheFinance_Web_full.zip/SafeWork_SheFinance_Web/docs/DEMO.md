# Demo Guide

1. Start backend: cd server && ./run.sh
2. Start frontend: cd frontend && npm install && npm run dev
3. In frontend login page, enter a phone and click Sign In (demo mode).
4. On Dashboard, press SOS to POST /sos on backend (demo prints to console).
5. Use ngrok to expose backend for webhook testing.
