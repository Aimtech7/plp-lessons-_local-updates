# Supabase Setup Guide

1. Create a Supabase project at https://app.supabase.com.
2. In the SQL editor, run migrations to create tables (users, trusted_contacts, incidents, earnings, loans).
3. In Settings -> API, copy the URL and anon/public key into frontend .env and backend .env.
4. Use Supabase Auth for phone/email OTP in production.
